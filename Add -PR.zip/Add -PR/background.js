// listen for our browerAction to be clicked

// https://stackoverflow.com/questions/8490385/chrome-extension-execute-every-x-minutes
chrome.tabs.onUpdated.addListener(function (tabId , info, tab) {
	console.log("current status = " + info.status);
	if(info.status == 'complete'){
		console.log("running injection 3 times");
		// Run every three seconds
		// runs three times
		var timesRan = 0;
		var myIntervals={};
		myIntervals[0] = setInterval(function(){
		if(timesRan < 3){	
			setTimeout(function () {
										chrome.tabs.executeScript(tab.tabId, { file: "jquery.js" }, function() {
										chrome.tabs.executeScript(tab.tabId, { file: "inject.js" });
									});
									}, 500);
		
			}		
		}, 1000*3); 
		
		
		// Clear it out after 9 seconds. 
		var timedEvent = setTimeout(function() {
			console.log("clearing interval");
			clearInterval(myIntervals[0]);
		}, 9100);
		
	}
});